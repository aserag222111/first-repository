class Car:
    def __init__(self, marka,age,model):
        self.marka = marka
        self.age = age
        self.model = model



    def hello(self):
        print('car:', self.marka, self.model,self.age)

car1 = Car('toyota', 2020,'camri')
car1.hello()
