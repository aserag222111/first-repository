class Hero:
    def __init__(self, name):
        self.name = name
        self.lives = 3
        self.level = 1

    def hello(self):
        print('hello, im ' + self.name)

hero1 = Hero('Anton')
hero1.hello()
hero2 = Hero('Maksim')
