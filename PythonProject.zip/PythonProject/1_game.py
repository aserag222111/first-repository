import pygame
from pygame.examples.aliens import Player
pygame.init()
width = 800
height = 800
clock = pygame.time.Clock()
fps = 60
display = pygame.display.set_mode ((width,height))
pygame.display.set_caption('Platformer')
sprite_image = pygame.image.load('images/player1.png')
sprite_rect = sprite_image.get_rect()
bg_image = pygame.image.load('images/bg5.png')
bg_rect = bg_image.get_rect()

class Player:
    def __init__(self):
        self.images_right = []
        self.images_left = []
        self.index = 0
        self.counter = 0
        self.direction = 0
        for num in range(1,2):
            img_right = pygame.image.load(f'images/player{num}.png')
            img_right = pygame.transform.scale(img_right, (35, 70))
            img_left = pygame.transform.flip(img_right, True, False)
            self.images_right.append(img_right)
            self.images_left.append(img_left)
        self.image = self.images_right[self.index]
        self.rect = self.image.get_rect()
        self.rect.x = 100
        self.rect.y = height -40 -70
        self.gravity = 0
        self.jumped = False

    def update(self):
        x = 0
        y = 0
        walk_speed = 10
        key = pygame.key.get_pressed()
        if key [pygame.K_SPACE] and self. jumped == False:
            self.gravity = -15
            #self.jumped = True
        if key[pygame.K_LEFT]:
            x -=5
            self.direction = -1
            self.counter += 1
        if key[pygame.K_RIGHT]:
            x+= 5
            self.direction = 1
            self.counter += 1

        if self.counter > walk_speed:
            self.counter = 0
            self.index += 1
            if self.index >= len(self.images_right):
                self.index = 0
            if self.direction == 1:
                self.images_right[self.index]
            else:
                self.images_left[self.index]



        self.gravity += 1
        if self.gravity > 10:
            self.gravity = 10
            
        y += self.gravity

        self.rect.x += y
        self.rect.y += y

        if self.rect.bottom > height:
            self.rect.bottom = height


        display.blit(self.image, self.rect)

player = Player()

run = True
while run:
    clock.tick(fps)
    display.blit(bg_image, bg_rect)
    #display.blit(sprite_image, sprite_rect)
    player.update()
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False

    pygame.display.update()

pygame.quit()

